<?php
    error_reporting(E_ALL ^ E_NOTICE);

    $app = isset($_POST["app"]) ? $_POST["app"] : "";
    $log = isset($_POST["log"]) ? $_POST["log"] : "";

    if (empty($app))
    {
        $app = "log";
    }
    if (!empty($log))
    {
        echo(file_put_contents($app." ".date("Y-m-d")." ".$_SERVER["REMOTE_ADDR"].".txt", $log, FILE_APPEND));
    }
?>