<?php

set_time_limit(600);
error_reporting(E_ALL);

$method = $_SERVER["REQUEST_METHOD"];

if ($method === "OPTIONS")
{
    set_cors_headers();
    exit();
}

$rawdata = json_decode(file_get_contents("php://input"));

if ($method === "POST")
{
    if (empty($rawdata))
    {
        exit("Invalid or Missing POST Data");
    }

    $body = property_exists($rawdata, "body") ? $rawdata->{"body"} : null;
    $cookies = $rawdata->{"cookies"};
    $url = $rawdata->{"url"};
}
else
{
    $body = null;
    $cookies = null;
    $url = $_GET["uri"];
}

$logging = false;
$log = "";
$type = "GET";
$parse = parse_url($url);
$host = $parse["host"];
$domain = "siriusxm.com";
$cookieString = "";

if (substr($host, -strlen($domain)) !== $domain)
{
    exit("Invalid Host Domain: " + $host);
}

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLINFO_HEADER_OUT, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 600);
curl_setopt($ch, CURLOPT_FAILONERROR, true);

$requestHeaders = getallheaders();
$headers = array();
$blockFields = array("Accept", "Accept-Encoding", "Accept-Language", "Content-Length", "Cookie", "Host", "Origin");

foreach ($requestHeaders as $key => $value)
{
    if (!in_array($key, $blockFields))
    {
        $headers[] = "$key: $value";
    }
}

$headers[] = "Origin: http://localhost";

if (!empty($body))
{
    $type = "POST";
    $body = json_encode($body);
    $headers[] = "Content-Length: ".strlen($body);

    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
}

if (isset($_GET["sxmmymixtoken"]) && isset($_GET["jsessionid"]))
{
    $cookieString = "SXMMYMIXTOKEN=".$_GET["sxmmymixtoken"]."; JSESSIONID=".$_GET["jsessionid"];
}
else if (!empty($cookies))
{
    foreach ($cookies as $key => $value)
    {
        $cookieString .= $key."=".$value.";";
    }
}

curl_setopt($ch, CURLOPT_COOKIE, $cookieString);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

log_section($type, $url, "REQUEST");
log_data("HEADERS", array_to_string($headers));
log_data("COOKIES", $cookieString);

if ($type == "POST")
{
    log_data("BODY", $body);
}

$response = curl_exec($ch);
set_cors_headers();

if (curl_errno($ch) > 0)
{
    //Add error-handling for this on the client side
    echo "Curl error: ".curl_error($ch);
}
else
{
    log_section($type, $url, "RESPONSE");

    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $header = substr($response, 0, $header_size);
    $body = substr($response, $header_size);

    log_data("HEADERS", $header);
    log_data("BODY", $body);

    set_headers($header);
    $cookies = get_cookies($header);

    if ($logging)
    {
        file_put_contents("log.txt", $log, FILE_APPEND);
    }

    header("Content-Type: ".curl_getinfo($ch, CURLINFO_CONTENT_TYPE));
    print_r(json_encode(array("body" => $body, "cookies" => $cookies)));
}

// close cURL resource, and free up system resources
curl_close($ch);

function array_to_string($array)
{
    $output = "";

    foreach ($array as $key => $value)
    {
        $output .= $key.": ".$value."\n";
    }

    return $output;
}

function get_cookies($header)
{
    $cookies = array();
    $matches = array();
    preg_match_all("/Set-Cookie:(?<cookie>\s{0,}.*)$/im", $header, $matches);

    foreach ($matches["cookie"] as $item)
    {
        $items = explode(";", trim($item));
        $index = strpos($items[0], "=");
        $key = substr($items[0], 0, $index);
        $value = substr($items[0], $index + 1);
        $expires = 0;

        foreach ($items as $part)
        {
            $parts = explode("=", trim($part));

            if ($parts[0] == "Expires")
            {
                $expires = strtotime($parts[1]);
                $maxTime = strtotime("+1 year");

                if ($expires > $maxTime)
                {
                    $expires = $maxTime;
                }
            }
        }

        $cookies[] = array("key" => $key, "value" => $value, "expires" => $expires);
    }

    return $cookies;
}

function log_data($caption, $data = null)
{
    global $logging, $log;

    if ($logging)
    {
        if (!is_null($data))
        {
            $caption .= ":\n\n".$data;
        }

        $log .= $caption."\n\n";
    }
}

function log_section($type, $url, $header)
{
    log_data($type." ".$header." ========================================================================");
    log_data(date("Y-m-d H:i:s"));
    log_data($url);
}

function set_cors_headers()
{
    header("Access-Control-Allow-Headers: Content-Type");
    header("Access-Control-Allow-Origin: *");
}

function set_headers($header)
{
    $headers = explode("\n", $header);

    foreach ($headers as $headerLine)
    {
        if (stripos($headerLine, "X-Mountain-Notification") !== false ||
            stripos($headerLine, "CrossDevicePausePointTime") !== false)
        {
            header($headerLine);
        }
    }
}

?>